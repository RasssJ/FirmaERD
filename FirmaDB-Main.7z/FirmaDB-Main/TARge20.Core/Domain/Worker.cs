﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Worker
    {
        [Key]
        public Guid ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public ICollection<WorkerProffession> WorkerProffession_ID { get; set; }
        public ICollection<SickDay> SickDays_ID { get; set; }
        public ICollection<Renting> Rentings_ID { get; set; }
        public ICollection<Child> Children_ID { get; set; }
        public ICollection<Vacation> Vacations_ID { get; set; }
    }
}
